<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Category>
 */
class SecurityController extends Controller
{
    public function encryptData(Request $request)
    {
        $output = shell_exec('python security.py');
        echo $output;

    }

class CategoryFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => $this->faker->unique()->words(2, true), // Generates a two-word English-like name
            'image' => 'category.jpg', // Default value
            'description' => $this->faker->sentence(10), // Optional description
        ];
    }
}
