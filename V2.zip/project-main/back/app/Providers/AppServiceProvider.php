<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
class SecurityController extends Controller
{
    public function encryptData(Request $request)
    {
        $output = shell_exec('python security.py');
        echo $output;

    }

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
