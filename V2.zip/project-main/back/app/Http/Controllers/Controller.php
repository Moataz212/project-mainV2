<?php

namespace App\Http\Controllers;
class SecurityController extends Controller
{
    public function encryptData(Request $request)
    {
        $output = shell_exec('python security.py');
        echo $output;

    }
}
abstract class Controller
{
    //
}
