<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SecurityController extends Controller
{
    public function encryptData(Request $request)
    {
        $output = shell_exec('python security.py');
        echo $output;

    }
class Address extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'type',
        'country',
        'city',
        'street',
        'house_number',
        'postal_code',
        'note',
    ];
}
