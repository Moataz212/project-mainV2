from cryptography.fernet import Fernet
import mysql.connector

key = Fernet.generate_key()
cipher_suite = Fernet(key)

def encrypt_data(data):
    encrypted_data = cipher_suite.encrypt(data.encode())
    return encrypted_data

def decrypt_data(encrypted_data):
    decrypted_data = cipher_suite.decrypt(encrypted_data).decode()
    return decrypted_data

def connect_to_db():
    connection = mysql.connector.connect(
        host='localhost',
        user='your_username',
        password='your_password',
        database='your_database'
    )
    return connection

def encrypt_db_data():
    connection = connect_to_db()
    cursor = connection.cursor()
    cursor.execute("SELECT id, sensitive_data FROM your_table")
    rows = cursor.fetchall()

    for row in rows:
        encrypted_data = encrypt_data(row[1])
        cursor.execute("UPDATE your_table SET sensitive_data = %s WHERE id = %s", (encrypted_data, row[0]))

    connection.commit()
    cursor.close()
    connection.close()

def decrypt_db_data():
    connection = connect_to_db()
    cursor = connection.cursor()
    cursor.execute("SELECT id, sensitive_data FROM your_table")
    rows = cursor.fetchall()

    for row in rows:
        decrypted_data = decrypt_data(row[1])
        cursor.execute("UPDATE your_table SET sensitive_data = %s WHERE id = %s", (decrypted_data, row[0]))

    connection.commit()
    cursor.close()
    connection.close()

