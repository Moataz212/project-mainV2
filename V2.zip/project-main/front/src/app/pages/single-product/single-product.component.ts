import { Component } from '@angular/core';
import { ProductService } from '../../Services/product.service';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalService } from '../../Services/global.service';
import Swal from 'sweetalert2';
declare var $: any;

@Component({
  selector: 'app-single-product',
  templateUrl: './single-product.component.html',
  styleUrls: ['./single-product.component.css']
})
export class SingleProductComponent {

  product: any;
  id: any;
  activeImageIndex: number = 0;
  main_image: any = 'images/download.png';
  quantity: number = 1;
  addCart = {
    product_id: 0,
    qty: 0,
    is_collage: 0,
    is_offer: 0
  }

  constructor(private products: ProductService, private activated: ActivatedRoute, private router: Router, private global: GlobalService) {
  }

  ngOnInit() {
    this.activated.paramMap.subscribe(param => {
      this.id = param.get('id');
      this.products.singleProduct(this.id).subscribe(res => {
        if (res) {
          this.product = res;
          this.main_image = this.product?.images[0]
        } else {
          this.router.navigateByUrl('**')
        }
      }, (err) => { }, () => {
      });
    });
  }

  changeImage(index: number, src: any) {
    this.main_image = 'images/download.png'
    setTimeout(() => {
      this.main_image = src
    }, 100)
    this.activeImageIndex = index;
  }

  selectedSize: string = 'M';

  sizes: string[] = ['XS', 'S', 'M', 'L', 'XL'];

  selectSize(size: string): void {
    this.selectedSize = size;
  }

  increaseQuantity(): void {
    this.quantity++;
  }

  decreaseQuantity(): void {
    if (this.quantity > 1) {
      this.quantity--;
    }
  }
}
