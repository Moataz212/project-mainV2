import { Component } from '@angular/core';
import { ProductService } from '../../Services/product.service';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalService } from '../../Services/global.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrl: './products.component.css'
})
export class ProductsComponent {


  id: any;
  products: any;

  constructor(private product: ProductService, private activated: ActivatedRoute, private router: Router, private global: GlobalService) {
  }

  ngOnInit() {
    this.activated.paramMap.subscribe(param => {
      this.id = param.get('id');
      this.product.products(this.id).subscribe(res => {        
        this.products = res.products
      }, (err) => { }, () => {
      });
    });
  }
}
