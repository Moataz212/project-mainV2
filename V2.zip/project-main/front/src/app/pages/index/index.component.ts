import { Component } from '@angular/core';
import { HomeService } from '../../Services/home.service';
import { GlobalService } from '../../Services/global.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrl: './index.component.css'
})
export class IndexComponent {

  categories: any = [];

  constructor(private home: HomeService, private global: GlobalService) {
  }


  ngOnInit() {

    this.home.category().subscribe(res => {
      console.log(res);
      
      this.categories = res;
    }, (err) => { }, () => {
    })
  }

}
