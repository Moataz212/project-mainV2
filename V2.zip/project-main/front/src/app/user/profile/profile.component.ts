import { Component } from '@angular/core';
import { GlobalService } from '../../Services/global.service';
import { AuthService } from '../../Services/auth.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {

  userData: any = '';
  model = {
    name: '',
    email: '',
  };
  passwordModel = {
    current_password: '',
    password: '',
    password_confirmation: ''
  };
  constructor(private global: GlobalService, private auth: AuthService, private router: Router) {
    auth.getPrfile().subscribe(res => {
      this.model.name = res.data.name;
      this.model.email = res.data.email;
    }, (err) => {
      router.navigateByUrl('/')
    }, () => {
    })
  }

  handleSubmit(registerForm: any) {
    if (registerForm.valid) {
      this.auth.updateProfile(this.model).subscribe(
        (res) => {
          console.log(res);
          localStorage.setItem('user_name', res.data.name);
          Swal.fire({
            title: 'Success!',
            text: 'Update Prfile Successfully.',
            icon: 'success',
            timer: 1000,
            showConfirmButton: false
          });
        },
        (err) => {
          Swal.fire({
            title: 'Error!',
            text: 'Update Prfile failed. Please try again.',
            icon: 'error',
            confirmButtonText: 'OK'
          });
        }, () => {
        }
      );
    }
  }


  handlePasswordChange(passwordForm: any) {
    if (passwordForm.valid && (this.passwordModel.password_confirmation == this.passwordModel.password)) {
      this.auth.changePassword(this.passwordModel).subscribe(
        (res) => {
          this.passwordModel.current_password = ''
          this.passwordModel.password = ''
          this.passwordModel.password_confirmation = ''
          passwordForm.resetForm();
          Swal.fire({
            title: 'Success!',
            text: 'Change password Successfully.',
            icon: 'success',
            timer: 1000,
            showConfirmButton: false
          });
        },
        (err) => {
          Swal.fire({
            title: 'Error!',
            text: 'Change password failed. Please try again.',
            icon: 'error',
            confirmButtonText: 'OK'
          });
        }, () => {
        }
      );
    }
  }
}
