import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AddressService } from '../../Services/address.service';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalService } from '../../Services/global.service';

@Component({
  selector: 'app-create-address',
  templateUrl: './create-address.component.html',
  styleUrl: './create-address.component.css'
})
export class CreateAddressComponent {

  is_submit = false;
  id: any;
  editAddress: any;

  constructor(private address: AddressService, private router: Router, private activated: ActivatedRoute) {
  }

  ngOnInit() {
    this.activated.paramMap.subscribe(param => {
      this.id = param.get('id');
      if (this.id) {
        this.address.editAddress(this.id).subscribe(res => {
          this.editAddress = res.data;
          this.addressForm.patchValue({
            country: this.editAddress.country,
            city: this.editAddress.city,
            street: this.editAddress.street,
            house_number: this.editAddress.house_number,
            postal_code: this.editAddress.postal_code,
            note: this.editAddress.note,
            type: this.editAddress.type,
          });
        }, (err) => {
        }, () => {
        });
      }
    })
  }

  addressForm = new FormGroup({
    country: new FormControl(null, Validators.required),
    city: new FormControl(null, Validators.required),
    street: new FormControl(null, Validators.required),
    house_number: new FormControl(null, [Validators.required]),
    postal_code: new FormControl(null, [Validators.required]),
    note: new FormControl(null),
    type : new FormControl(null, Validators.required),
  });

  onSubmit() {
    this.is_submit = true
    if (this.addressForm.valid) {
      if (this.id == null) {
        this.address.addAddress(this.addressForm.value).subscribe(res => {
          Swal.fire({
            title: 'Success!',
            text: 'Add Address Successfuly.',
            icon: 'success',
            timer: 1000,
            showConfirmButton: false
          });
          this.router.navigateByUrl('/address')
        })
      } else {
        this.address.updateAddress(this.addressForm.value, this.id).subscribe(res => {
          Swal.fire({
            title: 'Success!',
            text: 'Update Address Successfuly.',
            icon: 'success',
            timer: 1000,
            showConfirmButton: false
          });
          this.router.navigateByUrl('/address')
        })
      }
    }
  }
}
