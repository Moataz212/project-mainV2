import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  src = ''

  baseUrl = 'http://127.0.0.1:8000/api/';

  constructor(private Http: HttpClient) {
  }

  login(obj:any):Observable<any> {
    return this.Http.post(`${this.baseUrl}login`,obj);
  }

  register(obj:any):Observable<any> {
    return this.Http.post(`${this.baseUrl}register`,obj);
  }

  getPrfile():Observable<any> {
    return this.Http.get(`${this.baseUrl}getProfile`);
  }

  updateProfile(obj:any):Observable<any> {
    return this.Http.post(`${this.baseUrl}updateProfile`,obj);
  }
  
  changePassword(obj:any):Observable<any> {
    return this.Http.post(`${this.baseUrl}changePassword`,obj);
  }
}
