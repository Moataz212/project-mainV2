import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  baseUrl = 'http://127.0.0.1:8000/api/';

  constructor(private Http: HttpClient) { }

  singleProduct(id: any): Observable<any> {
    return this.Http.get(`${this.baseUrl}products/${id}`);
  }

  products(id: any): Observable<any> {
    return this.Http.get(`${this.baseUrl}categories/${id}`);
  }
}
