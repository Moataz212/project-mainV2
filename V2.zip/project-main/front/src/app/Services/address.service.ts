import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AddressService {

  baseUrl = 'http://127.0.0.1:8000/api/';

  constructor(private Http: HttpClient) {
  }

  address(): Observable<any> {
    return this.Http.get(`${this.baseUrl}addresses`);
  }

  addAddress(obj: any): Observable<any> {
    return this.Http.post(`${this.baseUrl}addresses/store`, obj)
  }

  editAddress(id: any): Observable<any> {
    return this.Http.get(`${this.baseUrl}addresses/${id}`)
  }

  updateAddress(obj: any, id: any): Observable<any> {
    return this.Http.post(`${this.baseUrl}addresses/update/${id}`, obj)
  }

  deleteAddress( id: any): Observable<any> {
    return this.Http.get(`${this.baseUrl}addresses/destroy/${id}`)
  }
}
